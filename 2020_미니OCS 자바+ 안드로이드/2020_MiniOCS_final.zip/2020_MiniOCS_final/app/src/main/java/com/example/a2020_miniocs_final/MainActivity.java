package com.example.a2020_miniocs_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    MySQLConnect connService = new MySQLConnect();
    boolean isService = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        serviceBind();
        findViewById(R.id.registrateButton).setOnClickListener(this);
        findViewById(R.id.diagnosisButton).setOnClickListener(this);
        findViewById(R.id.pharmacyButton).setOnClickListener(this);
        findViewById(R.id.surgeryButton).setOnClickListener(this);
        findViewById(R.id.statisticsButton).setOnClickListener(this);
        connService.sendMessage(new SocketMessage(SocketMessage.MsgType.OPEN, MiniOCSKey.android,"메인 화면!"));
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.registrateButton:
                startActivity(new Intent(this, RegistrateActivity.class));
                break;
            case R.id.diagnosisButton:
                startActivity(new Intent(this, DiagnosisActivity.class));
                finish();
                break;
            case R.id.pharmacyButton:
                startActivity(new Intent(this, SurgeryActivity.class));
                finish();
                break;
            case R.id.surgeryButton:
                startActivity(new Intent(this, StatisticsActivity.class));
                finish();
                break;
            case R.id.statisticsButton:
                startActivity(new Intent(this,StatisticsActivity.class));
                finish();
                break;
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(isService){
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            // 서비스와 연결되었을 때 호출되는 메서드
            // 서비스 객체를 전역변수로 저장
            MySQLConnect.MyBinder mb = (MySQLConnect.MyBinder) service;
            connService = mb.getService(); // 서비스가 제공하는 메소드 호출하여
            // 서비스쪽 객체를 전달받을수 있슴
            isService = true;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결",
                    Toast.LENGTH_LONG).show();
        }

        public void onServiceDisconnected(ComponentName name) {
            // 서비스와 연결이 끊겼을 때 호출되는 메서드
            isService = false;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결 해제",
                    Toast.LENGTH_LONG).show();
        }
    };

    public void serviceBind() {
        Intent intent = new Intent(
                MainActivity.this, // 현재 화면
                MySQLConnect.class); // 다음넘어갈 컴퍼넌트

        bindService(intent, // intent 객체
                conn, // 서비스와 연결에 대한 정의
                Context.BIND_AUTO_CREATE);
        //처음 서비스를 시작하는 액티비티에서는 Context.BIND_AUTO_CREATE
        //다른 액티비티에서는 Context.BIND_NOT_FOREGROUND를 주어야합니다.
    }

}
