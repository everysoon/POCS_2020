package com.example.a2020_miniocs_final;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.a2020_miniocs_final.Object.Medicine;
import com.example.a2020_miniocs_final.Object.Patient;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class MySQLConnect extends Service {

    public static ObjectInputStream reader = null;    // 수신용 스트림
    public static ObjectOutputStream writer = null;    // 송신용 스트림
    public static Socket sock = null;                // 서버 연결용 소켓

    SocketMessage message = null;
    SocketMessage.MsgType type = null;
    ArrayList<MiniOCSKey.RecyclerViewItem> ALLlist, PDlist, OSlist, GSlist, ENTlist, EYlist, MGlist;
    // 액티비티에서 onBind로 연결해주기 위해선 바인더 객체를 반환해야 함.
    // 바인더 객체를 생성하여 서비스 내의 메소드를 액티비티에서 활용할 수 있도록 해줌!
    IBinder mIBinder = new MyBinder();
    ArrayList<Patient> receivePatientList;
    ArrayList<Medicine> receiveMedicine;

    Intent messageIntent;
    boolean isReceive;

    class MyBinder extends Binder {
        //IBinder 객체를 생성할 때 new 연산자로 활용할 Binder 객체
        MySQLConnect getService() {
            //자기 자신 서비스를 반환!
            return MySQLConnect.this;
        }
    }

    public MySQLConnect() {
    }

    @Override
    public void onCreate() {
        //서비스를 생성했을 때 실행되는 메소드
        super.onCreate();
        new IncomingReader().start(); // 서버와 연결함과 동시에 비동기로 메세지를 수신하는 역할의 스레드
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; //서비스가 멈췄으면 다시 시작합니다.
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mIBinder;
    }

    public static void setupNetworking() {
        try {
            // setupNetworking
            sock = new Socket(MiniOCSKey.IP, MiniOCSKey.PORT);
            reader = new ObjectInputStream(sock.getInputStream());
            writer = new ObjectOutputStream(sock.getOutputStream());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class IncomingReader extends Thread {
        public synchronized void run() {
            try {
                setupNetworking();
                while (true) {
                    message = (SocketMessage) reader.readObject();
                    type = message.getType();
                    Log.e("받은message", message.toString());
                    if (type == SocketMessage.MsgType.RETURN_VALUE) {

                        if (message.getSender().equals(MiniOCSKey.DIAGNOSIS_ACTIVITY)) {
                            // DiagnosisActivity에서 사용 : 대기환자 받아옴
                            receivePatientList = message.getPatientlist();
                            isReceive = message.isIs_receive();
                            Log.e("mySQL1 :", isReceive + "");
                            if (message.getContents().equals(MiniOCSKey.OS)) {
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.OS, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.OS);


                            } else if (message.getContents().equals(MiniOCSKey.ALL)) {
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.ALL, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.ALL);


                            } else if (message.getContents().equals(MiniOCSKey.PD)) {
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.PD, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.PD);

                            } else if (message.getContents().equals(MiniOCSKey.GS)) {
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.GS, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.GS);

                            } else if (message.getContents().equals(MiniOCSKey.ENT)) {

                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.ENT, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.ENT);


                            } else if (message.getContents().equals(MiniOCSKey.EY)) {

                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.EY, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.EY);

                            } else if (message.getContents().equals(MiniOCSKey.MG)) {

                                messageIntent = new Intent(MiniOCSKey.RECEIVE_DIAGNOSIS);
                                messageIntent.putExtra(MiniOCSKey.MG, receivePatientList);
                                messageIntent.putExtra(MiniOCSKey.RECEIVE_PATIENT, MiniOCSKey.MG);

                            }
                            messageIntent.putExtra(MiniOCSKey.IS_REECEIVE, isReceive);
                            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(messageIntent);

                        } else if (message.getSender().equals(MiniOCSKey.PRESCRIPTION_ACTIVITY)) {
                            receivePatientList = message.getPatientlist();
                            //Prescription에서 환자 예전 진료기록 받아 올 때
                            messageIntent = new Intent(MiniOCSKey.RECEIVE_OLD_RECORD);
                            messageIntent.setAction(MiniOCSKey.RECEIVE_OLD_RECORD);
                            messageIntent.putExtra(MiniOCSKey.OLD_RECORD, receivePatientList);
                            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(messageIntent);
                            Log.e("서비스old?", receivePatientList.toString());
                        } else if (message.getActivityName().equals(MiniOCSKey.MEDICINE_SETUP)) {
                            // Medicine 정보 받은거 setup
                            receiveMedicine = message.getMedicineList();
                            isReceive = message.isIs_receive();
                            Log.e("medicine?", receiveMedicine.toString());
                            Log.e("mySQL2 :", isReceive + "");
                            if (message.getContents().equals(MiniOCSKey.MEDICINE_PP)) {
                                Log.e("PP?", receiveMedicine.toString());
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_MEDICINE);
                                messageIntent.setAction(MiniOCSKey.RECEIVE_MEDICINE);
                                messageIntent.putExtra(MiniOCSKey.MEDICINE_PP, receiveMedicine);

                            } else if (message.getContents().equals(MiniOCSKey.MEDICINE_IP)) {
                                Log.e("IP?", receiveMedicine.toString());
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_MEDICINE);
                                messageIntent.setAction(MiniOCSKey.RECEIVE_MEDICINE);
                                messageIntent.putExtra(MiniOCSKey.MEDICINE_IP, receiveMedicine);

                            } else if (message.getContents().equals(MiniOCSKey.MEDICINE_MP)) {
                                Log.e("MP?", receiveMedicine.toString());
                                messageIntent = new Intent(MiniOCSKey.RECEIVE_MEDICINE);
                                messageIntent.setAction(MiniOCSKey.RECEIVE_MEDICINE);
                                messageIntent.putExtra(MiniOCSKey.MEDICINE_MP, receiveMedicine);

                            }
                            messageIntent.putExtra(MiniOCSKey.IS_REECEIVE, isReceive);
                            LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(messageIntent);

                        }
                    }
                }
                   /* handler.post(new Runnable() {
                        @Override
                        public void run() {
                            // 스레드 안에서 UI접근 -> 핸들러
                        }
                    });*/

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    //서버에 메세지를 보내는 메소드입니다.
    public void sendMessage(final SocketMessage message) {
        //이는 스레드에서 동작해야 합니다.
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    writer.writeObject(message);
                    writer.flush();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Log.d("디버깅", "서버 상태 접속 실패");
                }
            }
        }).start();

    }
}
