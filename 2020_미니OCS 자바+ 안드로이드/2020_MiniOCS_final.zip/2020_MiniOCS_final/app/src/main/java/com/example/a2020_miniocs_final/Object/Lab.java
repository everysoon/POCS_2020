package com.example.a2020_miniocs_final.Object;

import com.example.a2020_miniocs_final.MiniOCSKey;

import java.io.Serializable;

public class Lab implements Serializable {
    private static final long serialVersionUID = MiniOCSKey.serialVersionUID;
    int lab_id;
    String lab_type;
    int lab_area; // 랩실 번호 [위치]
    String lab_status; // 랩실 사용 중? : on/off 로 표현
    String lab_time;

    public int getLab_id() {
        return lab_id;
    }

    public void setLab_id(int lab_id) {
        this.lab_id = lab_id;
    }

    public String getLab_type() {
        return lab_type;
    }

    public void setLab_type(String lab_type) {
        this.lab_type = lab_type;
    }

    public int getLab_area() {
        return lab_area;
    }

    public void setLab_area(int lab_area) {
        this.lab_area = lab_area;
    }

    public String getLab_status() {
        return lab_status;
    }

    public void setLab_status(String lab_status) {
        this.lab_status = lab_status;
    }

    public String getLab_time() {
        return lab_time;
    }

    public void setLab_time(String lab_time) {
        this.lab_time = lab_time;
    }
}
