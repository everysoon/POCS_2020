package com.example.a2020_miniocs_final.Object;

import com.example.a2020_miniocs_final.MiniOCSKey;

import java.io.Serializable;

public class Patient extends MiniOCSKey.RecyclerViewItem implements Serializable {
    // 안드로이드에서 사용하는 정보들을
    // DB에 접근하고 조작하기 위해 Patient,
    private static final long serialVersionUID = MiniOCSKey.serialVersionUID;

    public int patient_id; //환자 ID [PK] -> 바코드 번호
    public String patient_name; // 환자 이름
    public String patient_sex; // 환자 성별
    public int patient_age; // 환자 나이
    public String dateOfbirth; // 환자 생년월일

    // Dept + Doctor 테이블 접근을 위한 Doctor 객체
    Doctor doctor = new Doctor();
    // registration 테이블 정보들
    int registration_id;
    String diagnosis; // 병명
    String when_registration; // 접수시간 : "yy_mm_dd_hh:mm" 형식으로 저장
    String when_treat; // 언제 처방했는지 : "yy_mm_dd_hh:mm" 형식으로 저장
    String status; // 증상 메모
    // vital 테이블 정보
    int vital_id=0;
    String bp=null ; // 혈압 : "최고 혈압/최저 혈압"형식으로 저장
    String hr=null; //맥박 : INT형식
    String bt=null; // 체온 : DECIMAL(3,1) 형식
    String resp=null; //호흡수 : INT 형식 (12~18이 정상)
    String when_vital_check; // 언제 vital 체크했는지 : hh:mm 형식으로 저장
    public Patient(){}
    public Patient(int patient_id, String patient_name, String patient_sex, int patient_age, String dateOfbirth) {
        //환자 기본정보
        this.patient_id = patient_id;
        this.patient_name = patient_name;
        this.patient_sex = patient_sex;
        this.patient_age = patient_age;
        this.dateOfbirth = dateOfbirth;
    }

    public Patient(int patient_id, String patient_name, String patient_sex, int patient_age, String dateOfbirth, Doctor doctor) {
        // RegistrateActivity에서 환자 저장할때 : 환자기본정보 + 의사 + Dept
        this.patient_id = patient_id;
        this.patient_name = patient_name;
        this.patient_sex = patient_sex;
        this.patient_age = patient_age;
        this.dateOfbirth = dateOfbirth;
        this.doctor = doctor;
    }

    public Patient(int patient_id, String diagnosis, String when_registration, String when_treat, String status) {
        //자바->안드로이드에서 보내줄 때
        this.patient_id = patient_id;
        this.diagnosis = diagnosis;
        this.when_registration = when_registration;
        this.when_treat = when_treat;
        this.status = status;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public String getPatient_name() {
        return patient_name;
    }

    public void setPatient_name(String patient_name) {
        this.patient_name = patient_name;
    }

    public String getPatient_sex() {
        return patient_sex;
    }

    public void setPatient_sex(String patient_sex) {
        this.patient_sex = patient_sex;
    }

    public int getPatient_age() {
        return patient_age;
    }

    public void setPatient_age(int patient_age) {
        this.patient_age = patient_age;
    }

    public String getDateOfbirth() {
        return dateOfbirth;
    }

    public void setDateOfbirth(String dateOfbirth) {
        this.dateOfbirth = dateOfbirth;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public int getRegistration_id() {
        return registration_id;
    }

    public void setRegistration_id(int registration_id) {
        this.registration_id = registration_id;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getWhen_registration() {
        return when_registration;
    }

    public void setWhen_registration(String when_registration) {
        this.when_registration = when_registration;
    }

    public String getWhen_treat() {
        return when_treat;
    }

    public void setWhen_treat(String when_treat) {
        this.when_treat = when_treat;
    }

    public int getVital_id() {
        return vital_id;
    }

    public void setVital_id(int vital_id) {
        this.vital_id = vital_id;
    }

    public String getBp() {
        return bp;
    }

    public void setBp(String bp) {
        this.bp = bp;
    }

    public String getHr() {
        return hr;
    }

    public void setHr(String hr) {
        this.hr = hr;
    }

    public String getBt() {
        return bt;
    }

    public void setBt(String bt) {
        this.bt = bt;
    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getWhen_vital_check() {
        return when_vital_check;
    }

    public void setWhen_vital_check(String when_vital_check) {
        this.when_vital_check = when_vital_check;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "patient_id=" + patient_id +
                ", diagnosis='" + diagnosis + '\'' +
                ", when_registration='" + when_registration + '\'' +
                ", when_treat='" + when_treat + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
