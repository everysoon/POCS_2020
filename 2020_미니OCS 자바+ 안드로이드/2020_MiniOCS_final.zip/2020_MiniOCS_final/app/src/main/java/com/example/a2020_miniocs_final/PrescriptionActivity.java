package com.example.a2020_miniocs_final;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a2020_miniocs_final.Object.Medicine;
import com.example.a2020_miniocs_final.Object.Patient;

import java.util.ArrayList;

import me.relex.circleindicator.CircleIndicator;

public class PrescriptionActivity extends AppCompatActivity implements View.OnClickListener {

    TextView idText, nameText, sexText, ageText; //환자정보
    TextView BPtext, HRtext, BTtext, RESPtext;  //환자 vital정보
    TextView resultText; // 처방한 약들을 보여주는 Text
    Spinner classficationSpinner;
    RecyclerView MedicineRecyclerView;
    Button OPButton; // 수술지시버튼 -> 누르면 환자 정보 수술 접수 대기리스트로 전송

    // IP,PP,MP 에 해당하는 약 이름 arrays에서 받아옴
    ArrayList<MiniOCSKey.RecyclerViewItem> IPList = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> PPList = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> MPList = new ArrayList<>();

    //RecyclerView에 들어갈 ArrayList 정의 -> 1.처방내역 2.환자대기리스트 3.약
    ArrayList<MiniOCSKey.RecyclerViewItem> ALLlist;
    ArrayList<MiniOCSKey.RecyclerViewItem> OldList = new ArrayList<>();
    RecyclerViewAdapter medicineAdapter;

    //ViewPager에 사용될 변수들
    ViewPager viewPager;
    MyPagerAdapter viewPagerAdapter;
    CircleIndicator indicator;
    ViewPager_Fragment1 viewPagerFrag1;
    ViewPager_Fragment2 viewPagerFrag2;
    int pos;
    Bundle bundle = new Bundle();  // 프래그먼트 생성뒤 프래그먼트2에게 전달 : 전달하기위한 Bundle 생성
    //Dialog로 받아오는 정보
    Patient getPatient;
    //sql을 위한 서비스 생성
    MySQLConnect connService = new MySQLConnect();
    boolean isService = false;

    public interface onOldAdapter{
        //프래그먼트2에서 액티비티로 전달하기위함
        public void setOldAdapter(RecyclerViewAdapter adapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);

        serviceBind(); // 서비스 연결

        //xml정의
        idText = findViewById(R.id.patient_idText_prescription);
        nameText = findViewById(R.id.patient_nameText_prescription);
        sexText = findViewById(R.id.patient_sexText_prescription);
        ageText = findViewById(R.id.patient_ageText_prescription);
        BPtext = findViewById(R.id.patient_BP_prescription);
        HRtext = findViewById(R.id.patient_HR_prescription);
        BTtext = findViewById(R.id.patient_BT_prescription);
        RESPtext = findViewById(R.id.patient_RESP_prescription);
        resultText = findViewById(R.id.resultText_prescription);
        classficationSpinner = findViewById(R.id.medicine_ClassficationSpinner_prescription);
        MedicineRecyclerView = findViewById(R.id.prescription_medicineRecyclerView);

        getPatientInfo();// 데이터 세팅

        //환자의 예전기록 + 약 정보 요청

        //connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT,MiniOCSKey.android,MiniOCSKey.MEDICINE_SETUP,"SELECT * FROM medicine","약 정보 받아오기"));
       // LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter(MiniOCSKey.RECEIVE_MEDICINE));
        // 스피너설정
        String[] items = getResources().getStringArray(R.array.medicineClassfication);
        ArrayAdapter SpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items);
        classficationSpinner.setAdapter(SpinnerAdapter);
        classficationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // 스피너 전환에 따라 RecyclerView 전환 코드 넣어주기
                String classfication = (String) classficationSpinner.getSelectedItem();
                if (classfication.equals(MiniOCSKey.MEDICINE_PP)) {
                    medicineAdapter.upDateDateList(PPList);
                } else if (classfication.equals(MiniOCSKey.MEDICINE_IP)) {
                    medicineAdapter.upDateDateList(IPList);
                } else if (classfication.equals(MiniOCSKey.MEDICINE_MP)) {
                    medicineAdapter.upDateDateList(MPList);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        // RecyclerView 설정
        MedicineRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        medicineAdapter = new RecyclerViewAdapter(PrescriptionActivity.this, MiniOCSKey.MEDICINE, PPList);
        MedicineRecyclerView.setAdapter(medicineAdapter);
        medicineAdapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, int position, Patient patient) {
                pos = position;
            }

            @Override
            public void onMedicineClick(View v, Medicine medicine) {
                // 클릭한 Medicine 객체 받아오기
                String prescriptionText = medicine.getMedicine_name() + " : " + medicine.getMedicinePrescription();
                String getResultText = resultText.getText().toString() + "\n";
                resultText.setText(getResultText.concat(prescriptionText));
            }

            @Override
            public void onItemBarcodeCheck(boolean check) {

            }
        });
        medicineAdapter.notifyDataSetChanged();
        MedicineRecyclerView.setHasFixedSize(true);

        //ViewPager설정 (0)
        viewPagerFrag1 = new ViewPager_Fragment1();
        viewPagerFrag2 = new ViewPager_Fragment2();
        viewPager = findViewById(R.id.viewPager_prescription);
        viewPagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(viewPagerAdapter);
        indicator = findViewById(R.id.indicator);
        indicator.setViewPager(viewPager);

        // 1. 환자 대기 리스트 : 인텐트로 환자 대기 명단 받음
        ALLlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.PATIENT_LIST);
        bundle.putSerializable(MiniOCSKey.PATIENT_LIST, ALLlist);
        bundle.putSerializable(MiniOCSKey.CLICK_PATIENT_POSITON, pos);
        // 2. 환자의 예전 의료기록
        OldList = (ArrayList<MiniOCSKey.RecyclerViewItem>)getIntent().getSerializableExtra(MiniOCSKey.OLD_RECORD);
        bundle.putSerializable(MiniOCSKey.OLD_RECORD, OldList);
        Log.e("인텐트 받은",OldList.toString());
        viewPagerAdapter.setBundle(bundle);

        // 버튼 이벤트 처리
        OPButton = findViewById(R.id.OP_moveButton_prescription);
        OPButton.setOnClickListener(this);
        findViewById(R.id.cancelButton_prescription).setOnClickListener(this);
        findViewById(R.id.saveButton_prescription).setOnClickListener(this);
        findViewById(R.id.SCH_Banner).setOnClickListener(this);

    }

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // 서비스로 부터 데이터 전달받는 브로드캐스트 리시버
            if(intent.getAction().equals(MiniOCSKey.RECEIVE_OLD_RECORD)) {
                OldList = (ArrayList) intent.getSerializableExtra(MiniOCSKey.OLD_RECORD);
                Log.e("receive", OldList.toString());
               // RecyclerViewAdapter oldAdapter = viewPagerFrag2.getOldAdapter();
               // viewPagerFrag2.dataUpdate(oldAdapter,OldList);
              //  viewPagerFrag2.dataUpdate(OldList);
             //  viewPagerAdapter.notifyDataSetChanged();
            }
           // 약 데이터 얻어오기
            else if(intent.getAction().equals(MiniOCSKey.RECEIVE_MEDICINE)) {
                PPList = (ArrayList) intent.getSerializableExtra(MiniOCSKey.MEDICINE_PP);
                Log.e("receiveMedicine",PPList.toString());
                MPList = (ArrayList) intent.getSerializableExtra(MiniOCSKey.MEDICINE_MP);
                IPList = (ArrayList) intent.getSerializableExtra(MiniOCSKey.MEDICINE_IP);
                medicineAdapter.notifyDataSetChanged();// 데이터 체인지
            }
        }
    };
    public void getPatientInfo(){
        getPatient = (Patient) getIntent().getSerializableExtra(MiniOCSKey.PATIENT);

        idText.setText(String.valueOf(getPatient.getPatient_id()));
        nameText.setText(getPatient.getPatient_name());
        sexText.setText(getPatient.getPatient_sex());
        ageText.setText(String.valueOf(getPatient.getPatient_age()));
        BPtext.setText(getPatient.getBp());
        HRtext.setText(getPatient.getHr());
        BTtext.setText(getPatient.getBt());
        RESPtext.setText(getPatient.getResp());
        // 예전의료기록은 임의의 값을 집어 넣음 : 없으면 안넣기

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.SCH_Banner:
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
            case R.id.cancelButton_prescription:
                break;
            case R.id.saveButton_prescription:
                break;
        }
    }

    public static class MyPagerAdapter extends FragmentPagerAdapter {
        private static int NUM_ITEM = 2;
        ViewPager_Fragment1 viewPagerFragment1;
        ViewPager_Fragment2 viewPagerFragment2;
        Bundle bundle;

        public MyPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    viewPagerFragment1 = new ViewPager_Fragment1();
                    return viewPagerFragment1;
                case 1:
                    viewPagerFragment2 = new ViewPager_Fragment2();
                    viewPagerFragment2.setArguments(bundle);
                    return viewPagerFragment2;
                default:
                    return null;
            }

        }

        public void setBundle(Bundle bundle) {
            this.bundle = bundle;
        }

        @Override
        public int getCount() {
            return NUM_ITEM;
        }

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("디스토로이",isService+"");
        if(isService){
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            // 서비스와 연결되었을 때 호출되는 메서드
            // 서비스 객체를 전역변수로 저장
            MySQLConnect.MyBinder mb = (MySQLConnect.MyBinder) service;
            connService = mb.getService(); // 서비스가 제공하는 메소드 호출하여
            // 서비스쪽 객체를 전달받을수 있슴
            isService = true;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결",
                    Toast.LENGTH_LONG).show();
        }

        public void onServiceDisconnected(ComponentName name) {
            // 서비스와 연결이 끊겼을 때 호출되는 메서드
            isService = false;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결 해제",
                    Toast.LENGTH_LONG).show();
        }
    };

    public void serviceBind() {
        Intent intent = new Intent(
                PrescriptionActivity.this, // 현재 화면
                MySQLConnect.class); // 다음넘어갈 컴퍼넌트

        bindService(intent, // intent 객체
                conn, // 서비스와 연결에 대한 정의
                Context.BIND_NOT_FOREGROUND);
        //처음 서비스를 시작하는 액티비티에서는 Context.BIND_AUTO_CREATE
        //다른 액티비티에서는 Context.BIND_NOT_FOREGROUND를 주어야합니다.
    }
}
