package com.example.a2020_miniocs_final.Object;

import com.example.a2020_miniocs_final.MiniOCSKey;

import java.io.Serializable;

public class Dept implements Serializable {
    private static final long serialVersionUID = MiniOCSKey.serialVersionUID;
    int dept_id;
    String dept_name; // 진료과 이름
    int dept_location; // 어디에 위치해 있는지 [진료실 위치]
    public Dept(){

    }
    public Dept(String dept_name, int dept_location) {
        this.dept_name = dept_name;
        this.dept_location = dept_location;
    }

    public int getDept_id() {
        return dept_id;
    }

    public void setDept_id(int dept_id) {
        this.dept_id = dept_id;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    public int getDept_location() {
        return dept_location;
    }

    public void setDept_location(int dept_location) {
        this.dept_location = dept_location;
    }
}
