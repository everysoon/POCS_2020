package com.example.a2020_miniocs_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a2020_miniocs_final.Object.Dept;
import com.example.a2020_miniocs_final.Object.Doctor;
import com.example.a2020_miniocs_final.Object.Patient;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RegistrateActivity extends AppCompatActivity implements View.OnClickListener {

    MySQLConnect connService = new MySQLConnect();
    boolean isService = false;

    //dateOfBirth는 생년월일
    EditText idText, nameText;
    TextView todayText, ageText;
    Spinner yearSpinner, monthSpinner, daySpinner, deptSpinner, doctorSpinner, officeSpinner;
    RadioButton RadiocheckedButton;
    RadioGroup sexGroup;
    //스피너 설정을 위한 String[]배열 -> res/layout/values/arrays에 정의된 문자열 배열을 가져와서 사용
    String[] years, months, days, depts, doctors, offices;
    String sex;
    // 환자 정보를 저장 할 Patient 객체 + DB에 저장할 것들
    Patient newPatient;
    int dept_id;
    int doctor_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrate);
        connService.sendMessage(new SocketMessage(SocketMessage.MsgType.OPEN, MiniOCSKey.android, "안드로이드 접속!"));
        serviceBind();
        //xml정의
        connService.sendMessage(new SocketMessage(SocketMessage.MsgType.OPEN, MiniOCSKey.android, "안드로이드 접속!"));
        idText = (EditText) findViewById(R.id.patient_idText_registrate);
        nameText = (EditText) findViewById(R.id.patient_nameText_registrate);
        todayText = (TextView) findViewById(R.id.todayText_registrate);
        ageText = (TextView) findViewById(R.id.ageText_registrate);
        todayText.setText(MiniOCSKey.todayCalcultate_yyyyMMddEE());
        //    RadioButton - > AppCompatRadioButton : 라디오버튼에 색깔주기위해(buttonTint) AppCompat꺼 사용
        sexGroup = findViewById(R.id.sexGroup);
        sexGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadiocheckedButton = (RadioButton) findViewById(sexGroup.getCheckedRadioButtonId());
                if (RadiocheckedButton.getText().toString().equals("여"))
                    sex = "F";
                else sex = "M";
            }
        });
        //    스피너 설정
        deptSpinner = (Spinner) findViewById(R.id.deptSpinner_registrate);
        doctorSpinner = (Spinner) findViewById(R.id.doctorSpinner_registrate);
        officeSpinner = (Spinner) findViewById(R.id.officeSpinner_registrate);

        yearSpinner = (Spinner) findViewById(R.id.yearspinner_registrate);
        monthSpinner = (Spinner) findViewById(R.id.monthspinner_registrate);
        daySpinner = (Spinner) findViewById(R.id.dayspinner_registrate);

        //    스피너에 들어갈 데이터 배열은 res/layout/values/arrays에 정의하고 가져옴
        depts = getResources().getStringArray(R.array.dept);
        months = getResources().getStringArray(R.array.month);
        days = getResources().getStringArray(R.array.day);
        years = getResources().getStringArray(R.array.year);
        doctors = getResources().getStringArray(R.array.doctor);
        offices = getResources().getStringArray(R.array.office);
        //  arrays에 배열에 년도를 역순정렬하기위해 뒤집어줌
        List<String> list = Arrays.asList(years);
        Collections.reverse(list);
        years = list.toArray(new String[list.size()]);
        //    스피너 Adapter 설정
        ArrayAdapter DeptAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.dept));
        deptSpinner.setAdapter(DeptAdapter);
        deptSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectDept = (String)deptSpinner.getSelectedItem();
                if(selectDept.equals(MiniOCSKey.MG)) dept_id = 2;
                else if(selectDept.equals(MiniOCSKey.GS)) dept_id =3;
                else if(selectDept.equals(MiniOCSKey.EY)) dept_id =4;
                else if(selectDept.equals(MiniOCSKey.PD)) dept_id = 5;
                else if(selectDept.equals(MiniOCSKey.ENT)) dept_id =6;
                else if(selectDept.equals(MiniOCSKey.OS)) dept_id =7;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        ArrayAdapter YearAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, years);
        yearSpinner.setAdapter(YearAdapter);
        ArrayAdapter MonthAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.month));
        monthSpinner.setAdapter(MonthAdapter);
        ArrayAdapter DaysAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.day));
        daySpinner.setAdapter(DaysAdapter);
        ArrayAdapter DoctorsAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.doctor));
        doctorSpinner.setAdapter(DoctorsAdapter);
        doctorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectDoctor = (String)doctorSpinner.getSelectedItem();
                if(selectDoctor.equals(MiniOCSKey.oh)) doctor_id =1;
                else if(selectDoctor.equals(MiniOCSKey.min))doctor_id=2;
                else if(selectDoctor.equals(MiniOCSKey.gi))doctor_id=3;
                else if(selectDoctor.equals(MiniOCSKey.e)) doctor_id=4;
                else if(selectDoctor.equals(MiniOCSKey.ahn))doctor_id=5;
                else if(selectDoctor.equals(MiniOCSKey.soon))doctor_id=6;

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        ArrayAdapter OfficesAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.office));
        officeSpinner.setAdapter(OfficesAdapter);
        // yearSpinner 를 이용해 자동 나이 계산을 위해 이벤트 설정
        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String selectYear = (String) yearSpinner.getSelectedItem();
                int age = 2020 - Integer.parseInt(selectYear.trim()) + 1;
                ageText.setText(String.valueOf(age));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(getApplicationContext(), "생년월일을 선택해주세요.", Toast.LENGTH_SHORT).show();
            }
        });

        //    버튼 이벤트 설정
        findViewById(R.id.barcodeButton_registrate).setOnClickListener(this);
        findViewById(R.id.registrateButton_registrate).setOnClickListener(this);
        findViewById(R.id.SCH_Banner).setOnClickListener(this);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isService) {
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            // 서비스와 연결되었을 때 호출되는 메서드
            // 서비스 객체를 전역변수로 저장
            MySQLConnect.MyBinder mb = (MySQLConnect.MyBinder) service;
            connService = mb.getService(); // 서비스가 제공하는 메소드 호출하여
            // 서비스쪽 객체를 전달받을수 있슴
            isService = true;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결",
                    Toast.LENGTH_LONG).show();
        }

        public void onServiceDisconnected(ComponentName name) {
            // 서비스와 연결이 끊겼을 때 호출되는 메서드
            isService = false;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결 해제",
                    Toast.LENGTH_LONG).show();
        }
    };

    public void serviceBind() {
        Intent intent = new Intent(
                RegistrateActivity.this, // 현재 화면
                MySQLConnect.class); // 다음넘어갈 컴퍼넌트

        bindService(intent, // intent 객체
                conn, // 서비스와 연결에 대한 정의
                Context.BIND_NOT_FOREGROUND);
        //처음 서비스를 시작하는 액티비티에서는 Context.BIND_AUTO_CREATE
        //다른 액티비티에서는 Context.BIND_NOT_FOREGROUND를 주어야합니다.
    }

    public void CreatePatient() {
        newPatient = new Patient(Integer.parseInt(idText.getText().toString()), nameText.getText().toString(), sex,
                Integer.parseInt(ageText.getText().toString()), yearSpinner.getSelectedItem().toString() + "-" + monthSpinner.getSelectedItem().toString() + "-" + daySpinner.getSelectedItem().toString(),
                new Doctor(doctorSpinner.getSelectedItem().toString(),
                        new Dept(deptSpinner.getSelectedItem().toString(), Integer.parseInt(officeSpinner.getSelectedItem().toString()))));

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.barcodeButton_registrate:
                // 1.바코드리더기 읽어서 ID 설정 -> idText로 포커스 옮긴 뒤 바코드 딸깍
                idText.requestFocus();
                // 2. 설정된 ID idText에 setText하기
                break;
            case R.id.registrateButton_registrate:
                CreatePatient(); // 환자 객체로 만들어 정보 저장
                connService.sendMessage(new SocketMessage(SocketMessage.MsgType.INSERT, MiniOCSKey.android, "INSERT INTO patient VALUES(" +
                        newPatient.getPatient_id() + ",'" + newPatient.getPatient_name() + "','" + newPatient.getPatient_sex() + "'," + newPatient.getPatient_age() + ",'" +
                        newPatient.getDateOfbirth() + "')")); // 환자 객체 등록
                connService.sendMessage(new SocketMessage(SocketMessage.MsgType.INSERT,MiniOCSKey.android,
                        "INSERT (patient_id,dept_id,diagnosis,when_registration,when_treat,status,doctor_id)"+
                        "INTO registration VALUES("+newPatient.getPatient_id()+","+dept_id+","+"null,"+MiniOCSKey.todayCalcultate_yyyyMMddHHss()+
                                ",null,null,"+doctor_id+")")); //registration 테이블 등록 - 환자 id 집어넣어서!
                Toast.makeText(this, "접수가 완료되었습니다.", Toast.LENGTH_SHORT).show();
                finish();
                break;
            case R.id.SCH_Banner:
                // 메인 화면으로 이동
                startActivity(new Intent(RegistrateActivity.this, MainActivity.class));
                finish();
                break;

        }
    }
}
