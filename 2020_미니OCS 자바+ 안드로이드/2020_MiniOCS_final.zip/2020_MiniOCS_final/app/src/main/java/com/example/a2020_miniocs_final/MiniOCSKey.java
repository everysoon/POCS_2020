package com.example.a2020_miniocs_final;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Vector;

/**
 * PD : PeDiatrics(소아과) , OS : Ortho Surgery (정형외과) ,
 * GS : General Surgery(일반 외과) , ENT : Ear,Nose & Throat (이비인후과)
 * EY : EYe (안과)  , MG : Medicus Greatus (내과)
 */

public class MiniOCSKey {
    // MiniOCSKey는 공통변수를 관리하는 클래스입니다.
    //public static MySQLConnect myConn = new MySQLConnect();
    public static ProgressDialog oDialog;
    // Socket통신을 위한 변수
    public static final String IP = "220.69.203.24";
    public static final int PORT = 5000;
    public static final String android = "Android";
    public static final long serialVersionUID = 8358731843579430211L;
    // activity Name
    public static final String DIAGNOSIS_ACTIVITY = "DiagnosisActivity";
    public static final String PRESCRIPTION_ACTIVITY="PrescriptionActivity";
    //임시 doctor 이름들
    public static final String soon="박민선";
    public static final String oh="오동익";
    public static final String e="이언석";
    public static final String min="민세동";
    public static final String gi="권춘기";
    public static final String ahn="안재억";

    //    intent Message
    public static final String PATIENT = "patient";
    public static final String PATIENTLIST_DIAGNOSIS = "patientlist_diagnosis";
    public static final String PATIENTLIST_PRESCRIPTION = "patientlist_prescription";
    public static final String PHARMACY = "pharmacy";
    public static final String SURGERY = "surgery";
    public static final String MEDICINE = "medicine";
    public static final String PRESCRIPTION = "prescription";
    public static final String PATIENT_LIST = "patientList";
    public static final String OLD_RECORD = "oldRecord";
    public static final String CLICK_PATIENT_POSITON = "click_patient_position";

    public static final String MEDICNE_PRESCRIPTION = "medicine_prescription";
    public static final String IS_REECEIVE = "isReceive";
    public static final String RECEIVE_PATIENT = "receive_patient";
    public static final String RECEIVE_DIAGNOSIS = "receive_diagnosis";
    public static final String RECEIVE_OLD_RECORD = "receive_old_record";
    public static final String RECEIVE_MEDICINE = "receive_medicine";
    public static final String FALSE="false";
    public static final String MEDICINE_PP = "PP";
    public static final String MEDICINE_IP = "IP";
    public static final String MEDICINE_MP = "MP";
    public static final String MEDICINE_SETUP = "medicine_setup";

    //    dept
    public static final String OS = "정형외과";
    public static final String ENT = "이비인후과";
    public static final String MG = "내과";
    public static final String PD = "소아과";
    public static final String GS = "외과";
    public static final String EY = "안과";
    public static final String ALL = "ALL";

    //    Adapter
    public static final int PATIENTLIST_DIAGNOSIS_KEY = 0;
    public static final int PRESCRIPTION_KEY = 1;
    public static final int PHARMACY_KEY = 2;
    public static final int OLDRECORD_KEY = 3;
    public static final int MEDICINE_KEY = 4;
    public static final int PATIENTLIST_PRESCRIPTION_KEY = 5;
    public static final int MEDICINE_PRESCRIPTION_KEY = 6;


    public static class RecyclerViewItem implements Serializable {
        // 액티비티 별 리싸이클러 뷰에 들어가는 아이템들이 상속할 부모 클래스
    }

    static public String todayCalcultate_yyyyMMddEE() {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일 EE요일", Locale.getDefault()); // yyyy-MM-dd HH:mm:ss
        String today = dateFormat.format(currentTime);
        return today;
    }

    static public String todayCalcultate_yyyyMMdd() {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일", Locale.getDefault());
        String today = dateFormat.format(currentTime);
        return today;
    }
    static public String todayCalcultate_yyyyMMddHHss() {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yy_MM_dd_HH:ss", Locale.getDefault());
        String today = dateFormat.format(currentTime);
        return today;
    }
    static public void waitDialog(Context mContext) {
        oDialog = new ProgressDialog(mContext);
        oDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        oDialog.setCancelable(true);
        oDialog.setMessage("잠시만 기다려 주세요.");
    }

    static public void startDialog() {
        oDialog.show();
    }
/*    public static MySQLConnect getMyConn() {
        return myConn;
    }

    public static void setMyConn(MySQLConnect myConn) {
        MiniOCSKey.myConn = myConn;
        Log.e("myConn?",MiniOCSKey.myConn.toString());
    }*/
}
