package com.example.a2020_miniocs_final;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a2020_miniocs_final.Object.Prescription;

import java.util.ArrayList;

public class ViewPager_Fragment2 extends Fragment {
    RecyclerView PatientWaitRecyclerView, OldMedicalRecordRecyclerView;
    RecyclerViewAdapter waitAdapter = new RecyclerViewAdapter();
    RecyclerViewAdapter oldAdapter = new RecyclerViewAdapter();
    ArrayList<MiniOCSKey.RecyclerViewItem> ALLlist, OldList;
    int position;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.viewpager_fragment2, container, false);
        PatientWaitRecyclerView = view.findViewById(R.id.patient_waitList_prescription);
        OldMedicalRecordRecyclerView = view.findViewById(R.id.patient_oldMedicalrecord_prescription);
        // 1.환자 대기리스트 RecyclerView
        Bundle bundle = getArguments();
        ALLlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) bundle.getSerializable(MiniOCSKey.PATIENT_LIST);
        position = bundle.getInt(MiniOCSKey.CLICK_PATIENT_POSITON);
        PatientWaitRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        waitAdapter = new RecyclerViewAdapter(getContext(), MiniOCSKey.PATIENTLIST_PRESCRIPTION, ALLlist);
        PatientWaitRecyclerView.setAdapter(waitAdapter);
        waitAdapter.notifyDataSetChanged();
        // 3. 환자 예전 처방 리스트 RecyclerView
        OldList = (ArrayList<MiniOCSKey.RecyclerViewItem>) bundle.getSerializable(MiniOCSKey.OLD_RECORD);
        OldMedicalRecordRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        oldAdapter = new RecyclerViewAdapter(getContext(), MiniOCSKey.OLD_RECORD, OldList);
        OldMedicalRecordRecyclerView.setAdapter(oldAdapter);
        Log.e("pager",oldAdapter.toString());
        oldAdapter.notifyDataSetChanged();
        return view;
    }

    /*public void dataUpdate(ArrayList<MiniOCSKey.RecyclerViewItem> newData){
        Log.e("111","111");
        OldList = newData;
        //oldAdapter = adapter;
        oldAdapter.upDateDateList(OldList);
    }*/
/*    public RecyclerViewAdapter getOldAdapter(){
        Log.e("1",oldAdapter.toString());
        return oldAdapter;
    }*/
  /*  @Override
    public void setOldAdapter(RecyclerViewAdapter adapter) {
        oldAdapter = adapter;
        Log.e("222","222");
    }*/
}
