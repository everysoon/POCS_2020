package com.example.a2020_miniocs_final;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.a2020_miniocs_final.Object.Medicine;
import com.example.a2020_miniocs_final.Object.Patient;

import java.util.ArrayList;

public class DiagnosisActivity extends AppCompatActivity implements View.OnClickListener {
    /**
     * PD : PeDiatrics(소아과) , OS : Ortho Surgery (정형외과) ,
     * GS : General Surgery(일반 외과) , ENT : Ear,Nose & Throat (이비인후과)
     * EY : EYe (안과)  , MG : Medicus Greatus (내과)
     */
    Spinner deptSpinner; // 진료 과 별 환자 조회 가능하도록
    EditText idText;
    String getDept, getPatientID;
    Patient clickPatient = new Patient();

    // RecyclerView의 Item이 될 Vector 리스트들
    ArrayList<MiniOCSKey.RecyclerViewItem> ALLlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> PDlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> OSlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> GSlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> ENTlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> EYlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> MGlist = new ArrayList<>();
    ArrayList<MiniOCSKey.RecyclerViewItem> OldList = new ArrayList<>();
    RecyclerView patientRecyclerView;

    RecyclerViewAdapter adapter;
    /**
     * vital Dialog를 이용해 vital을 체크한 환자들은 콜백리스너를 통해 vital체크했다고 true를 리턴함
     * ->  vitalCheck 변수로 받아 스레드의 while 루프를 진행 또는 정지를 관리할 변수 : vitalCheck
     */
    Boolean vitalCheck = false;
    MySQLConnect connService = new MySQLConnect();
    boolean isService = false;
    boolean isReceive = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnosis);

        serviceBind(); // 서비스 연결

        ALLlist = new ArrayList<>();
        connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient", MiniOCSKey.ALL));
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter(MiniOCSKey.RECEIVE_PATIENT));
        // xml정의
        idText = findViewById(R.id.patient_idText_Diagnosis);
        patientRecyclerView = findViewById(R.id.patient_waitList_Diagnosis);
        deptSpinner = findViewById(R.id.deptSpinner_Diagnosis);

        //스피너 설정
        String[] items = getResources().getStringArray(R.array.dept);
        ArrayAdapter SpinnerAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items);
        deptSpinner.setAdapter(SpinnerAdapter);
        deptSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                // 스피너로 부서 변경될 때마다 아래의 환자 recyclerView 변하도록 코딩하기
                getDept = (String) deptSpinner.getSelectedItem();
                if (getDept.equals(MiniOCSKey.ALL)) {
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient", MiniOCSKey.ALL));
                    adapter.upDateDateList(ALLlist);
                    //전체
                } else if (getDept.equals(MiniOCSKey.OS)) {
                    //정형외과
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient WHERE dapt_id = 7", MiniOCSKey.OS));
                    adapter.upDateDateList(OSlist);
                } else if (getDept.equals(MiniOCSKey.MG)) {
                    //내과
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient WHERE dept_id = 2", MiniOCSKey.GS));
                    adapter.upDateDateList(MGlist);
                } else if (getDept.equals(MiniOCSKey.ENT)) {
                    //이비인후과
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient WHERE dept_id = 6", MiniOCSKey.ENT));
                    adapter.upDateDateList(ENTlist);
                } else if (getDept.equals(MiniOCSKey.EY)) {
                    // 안과
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient WHERE dept_id = 4", MiniOCSKey.EY));
                    adapter.upDateDateList(EYlist);
                } else if (getDept.equals(MiniOCSKey.GS)) {
                    //외과
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient WHERE dept_id = 3", MiniOCSKey.GS));
                    adapter.upDateDateList(GSlist);
                } else if (getDept.equals(MiniOCSKey.PD)) {
                    //소아과
                    connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.DIAGNOSIS_ACTIVITY, "SELECT * FROM patient WHERE dept_id = 5", MiniOCSKey.PD));
                    adapter.upDateDateList(PDlist);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        // 리싸이클러뷰 설정
        patientRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerViewAdapter(DiagnosisActivity.this, MiniOCSKey.PATIENTLIST_DIAGNOSIS, ALLlist);
        patientRecyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, int position, Patient getPatient) {
                getPatientID = String.valueOf(getPatient.getPatient_id());
                clickPatient = getPatient;
                connService.sendMessage(new SocketMessage(SocketMessage.MsgType.SELECT, MiniOCSKey.android, MiniOCSKey.PRESCRIPTION_ACTIVITY, "SELECT * FROM registration WHERE patient_id ="+clickPatient.getPatient_id(),"환자진료기록"));
                LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(receiver, new IntentFilter(MiniOCSKey.RECEIVE_OLD_RECORD));
            }

            @Override
            public void onMedicineClick(View v, Medicine medicine) {
            }

            @Override
            public void onItemBarcodeCheck(boolean check) {
                vitalCheck = check;
                barcode();
                idText.requestFocus();
            }
        });
        adapter.notifyDataSetChanged();
        patientRecyclerView.setHasFixedSize(true);
        findViewById(R.id.SCH_Banner).setOnClickListener(this);
        findViewById(R.id.refreshButton_Diagnosis).setOnClickListener(this);
    }


    public void barcode() {

        idText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (getPatientID != null) {
                    //PatientID가 null이 아니고
                    if (vitalCheck) {
                        //vital 데이터를 입력한 환자이고
                        if (getPatientID.equals(idText.getText().toString())) {
                            //idText에 바코드 값이 들어오고 , id가 일치하면
                            //화면전환
                            // 선택된 환자 대기리스트에서 삭제
                            ALLlist.remove(clickPatient);
                            // 선택된 환자 정보 진료화면으로 데이터 보내주기 + 남은 환자 리스트도!
                            Intent intent = new Intent(DiagnosisActivity.this, PrescriptionActivity.class);
                            intent.putExtra(MiniOCSKey.PATIENT, clickPatient);
                            intent.putExtra(MiniOCSKey.PATIENT_LIST, ALLlist);
                            intent.putExtra(MiniOCSKey.OLD_RECORD,OldList);
                            while (isReceive);
                            Log.e("isReceive?",isReceive+"");
                            Log.e("화면넘어가",OldList.toString());
                            startActivity(intent);
                            finish();
                            unbindService(conn); // 서비스 종료

                        } else {
                            Toast.makeText(getApplicationContext(), "환자의 ID를 확인해 주세요.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Log.e("getPatientID NULL!", "getPatientID NULL!");
                    }
                }
            }
        });
    }

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // 서비스로 부터 데이터 전달받는 브로드캐스트 리시버
            String getString = intent.getStringExtra(MiniOCSKey.IS_REECEIVE);
            if (getString.equals(MiniOCSKey.ALL)) {
                ALLlist = (ArrayList) intent.getSerializableExtra(MiniOCSKey.ALL);
                adapter.upDateDateList(ALLlist);
            } else if (getString.equals(MiniOCSKey.OS)) {
                OSlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.OS);
            } else if (getString.equals(MiniOCSKey.ENT)) {
                ALLlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.ENT);
            } else if (getString.equals(MiniOCSKey.EY)) {
                EYlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.EY);
            } else if (getString.equals(MiniOCSKey.GS)) {
                GSlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.GS);
            } else if (getString.equals(MiniOCSKey.PD)) {
                PDlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.PD);
            } else if (getString.equals(MiniOCSKey.MG)) {
                MGlist = (ArrayList<MiniOCSKey.RecyclerViewItem>) getIntent().getSerializableExtra(MiniOCSKey.MG);
            }
            if(intent.getAction().equals(MiniOCSKey.RECEIVE_OLD_RECORD)) {
                OldList = (ArrayList<MiniOCSKey.RecyclerViewItem>) intent.getSerializableExtra(MiniOCSKey.OLD_RECORD);
                Log.e("Diag?", OldList.toString());
                // RecyclerViewAdapter oldAdapter = viewPagerFrag2.getOldAdapter();
                // viewPagerFrag2.dataUpdate(oldAdapter,OldList);
            }
            isReceive =(boolean)intent.getBooleanExtra(MiniOCSKey.IS_REECEIVE,isReceive);
            Log.e("dig: ",isReceive+"");
        }
    };

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.SCH_Banner:
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isService) {
            Log.e("디스토리이", "디스트로이");
            unbindService(conn); // 서비스 종료
            isService = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            // 서비스와 연결되었을 때 호출되는 메서드
            // 서비스 객체를 전역변수로 저장
            MySQLConnect.MyBinder mb = (MySQLConnect.MyBinder) service;
            connService = mb.getService(); // 서비스가 제공하는 메소드 호출하여
            // 서비스쪽 객체를 전달받을수 있슴
            isService = true;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결",
                    Toast.LENGTH_LONG).show();
        }

        public void onServiceDisconnected(ComponentName name) {
            // 서비스와 연결이 끊겼을 때 호출되는 메서드
            isService = false;
            Toast.makeText(getApplicationContext(),
                    "서비스 연결 해제",
                    Toast.LENGTH_LONG).show();
        }
    };

    public void serviceBind() {
        Intent intent = new Intent(
                DiagnosisActivity.this, // 현재 화면
                MySQLConnect.class); // 다음넘어갈 컴퍼넌트

        bindService(intent, // intent 객체
                conn, // 서비스와 연결에 대한 정의
                Context.BIND_NOT_FOREGROUND);
        //처음 서비스를 시작하는 액티비티에서는 Context.BIND_AUTO_CREATE
        //다른 액티비티에서는 Context.BIND_NOT_FOREGROUND를 주어야합니다.
    }

}
