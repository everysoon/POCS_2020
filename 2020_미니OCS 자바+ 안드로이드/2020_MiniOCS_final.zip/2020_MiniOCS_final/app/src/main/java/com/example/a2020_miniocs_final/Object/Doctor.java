package com.example.a2020_miniocs_final.Object;

import com.example.a2020_miniocs_final.MiniOCSKey;

import java.io.Serializable;

public class Doctor implements Serializable {
    private static final long serialVersionUID = MiniOCSKey.serialVersionUID;
    // 데이터베이스 스키마에 있는 Department , Doctor 테이블 합함

    int doctor_id;
    String doctor_name;
    Dept dept = new Dept(); // 무슨 부서인지, 어디에 위치해있는지
    public Doctor(){}
    public Doctor(String doctor_name, Dept dept) {
        this.doctor_name = doctor_name;
        this.dept = dept;
    }

    public int getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(int doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }
}
