package com.example.a2020_miniocs_final.Object;

import com.example.a2020_miniocs_final.MiniOCSKey;

import java.io.Serializable;

public class Prescription extends MiniOCSKey.RecyclerViewItem implements Serializable  {
    private static final long serialVersionUID = MiniOCSKey.serialVersionUID;
    // 처방관련클래스 스키마의 Medicine_Prescription + Medicine 테이블
    int prescription_id;
    Medicine medicine;
    String give_out_status; // 약을 처방했는지 -> Y 또는 N
    String medicine_prescription; // aT_#b_cDay 형식

    Patient patient = new Patient();

    public int getPrescription_id() {
        return prescription_id;
    }

    public void setPrescription_id(int prescription_id) {
        this.prescription_id = prescription_id;
    }

    public Medicine getMedicine() {
        return medicine;
    }

    public void setMedicine(Medicine medicine) {
        this.medicine = medicine;
    }

    public String getGive_out_status() {
        return give_out_status;
    }

    public void setGive_out_status(String give_out_status) {
        this.give_out_status = give_out_status;
    }

    public String getMedicine_prescription() {
        return medicine_prescription;
    }

    public void setMedicine_prescription(String medicine_prescription) {
        this.medicine_prescription = medicine_prescription;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
}
